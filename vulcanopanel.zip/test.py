from pyupnp import *

def open_port(port, description):
    # Initialiseer UPnP
    upnp = UPnP()

    # Zoek naar de router
    upnp.discover()
    upnp.select()

    # Verkrijg de lokale IP-adres
    local_ip = upnp.lanaddr

    # Open de poort
    result = upnp.add_port_mapping(port, 'TCP', local_ip, port, description, 0)

    if result == 0:
        print(f"Poort {port} succesvol geopend.")
    else:
        print(f"Fout bij het openen van poort {port}: {result}")

if __name__ == "__main__":
    port_to_open = 8000  # Vervang dit door de poort die je wilt openen
    description = "Mijn Python UPnP Poort"  # Vervang dit door een beschrijving

    open_port(port_to_open, description)
