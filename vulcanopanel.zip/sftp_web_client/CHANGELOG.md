# v0.13.0 - 26. Feb. 2019
* added spanish support (thx @https://github.com/DrLecter)

# v0.12.0 - 14.04.2017 - alpha 4
* restrict access to web ftp client root for local browser
* allow self signed certs
* added default root directory for server and local browser


# v0.11.0 - 03.04.2017 - alpha 3
* added DE translation
* added dark/light theme
* added windows start bat file
* fixed problems with user management (pw hash and login tokens)
* moved transfer settings replace mode to contextmenu instead of dedicated settings
* changelog now comes from this changelog file instead of release info

# v0.10.0 - 01.04.2017 - alpha 2
* most features are basically tested and working
* numerous fixes and improvements

# v0.9.0 - 29.03.2017 -  alpha 1
* initial commit and alpha
