FTP/SFTP client feature:

A web based, always online, FTP/SFTP client. Like really simple, kind of, filezilla, but for your browser. The main goal of this tool is: Install on a server/raspberry/desktop and use it like a desktop tool.

showcase of the sftp client:

[![Screenshot](https://brainfoolong.github.io/web-ftp-client/images/web-ftp.png?2)](http://imgur.com/7xQLoXp)